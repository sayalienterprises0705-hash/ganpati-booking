document.addEventListener("DOMContentLoaded",()=>{const t=document.querySelector(".menu-toggle"),n=document.querySelector(".site-nav");if(t)t.onclick=()=>n.classList.toggle("open");const top=document.querySelector(".top-btn");if(top)top.onclick=()=>scrollTo({top:0,behavior:"smooth"});const f=document.getElementById("bookingForm");if(f)f.onsubmit=e=>{e.preventDefault();if(!f.checkValidity()){f.reportValidity();return}const v=id=>document.getElementById(id).value.trim();const msg=`🙏 NEW GANPATI BOOKING\nName: ${v("name")}\nMobile: ${v("mobile")}\nEmail: ${v("email")||"Not provided"}\nMurti: ${v("murti")}\nSize: ${v("size")}\nQuantity: ${v("qty")}\nPayment: ${v("payment")}\nDelivery: ${v("delivery")}\nPreferred Date: ${v("date")}\nAddress: ${v("address")}\nNote: ${v("note")||"None"}\n\nStatus: Pending manual confirmation\nS.B. Joshi Enterprises, 1237 Matruchaya Apartment, Krantivir Vasudev Balvant Phadke Road, Opp. Khunya Murlidhar Mandir, Sadashiv Peth, Pune 411030`;document.getElementById("msg").textContent="Opening WhatsApp…";window.open("https://wa.me/918857874068?text="+encodeURIComponent(msg),"_blank")}});

/* Pooja Artical catalogue and booking */
const POOJA_CATALOG = [{"category": "Agarbatti", "image": "agarbatti.svg", "name": "Agarbatti", "description": "Devotional incense sticks for a fragrant Ganesh puja.", "price": "₹ —"}, {"category": "Dhup", "image": "dhup.svg", "name": "Dhup", "description": "Traditional dhoop for a calm and auspicious pooja atmosphere.", "price": "₹ —"}, {"category": "Kapoor", "image": "kapoor.svg", "name": "Kapoor", "description": "Camphor for a bright, traditional Ganesh aarti.", "price": "₹ —"}, {"category": "Wati", "image": "wati.svg", "name": "Wati", "description": "Cotton wicks for diyas used during puja and aarti.", "price": "₹ —"}, {"category": "Attar", "image": "attar.svg", "name": "Attar", "description": "Fragrant attar for traditional devotional use.", "price": "₹ —"}, {"category": "Javnijod", "image": "javnijod.svg", "name": "Javnijod", "description": "Traditional pooja samagri used for auspicious rituals.", "price": "₹ —"}, {"category": "Vastramal", "image": "vastramal.svg", "name": "Vastramal", "description": "Traditional pooja/decorative material for Ganesh festival rituals.", "price": "₹ —"}, {"category": "Halad", "image": "halad.svg", "name": "Halad", "description": "Auspicious turmeric used in traditional pooja ceremonies.", "price": "₹ —"}, {"category": "Kunku", "image": "kunku.svg", "name": "Kunku", "description": "Traditional kumkum for Ganesh puja and auspicious occasions.", "price": "₹ —"}];

function renderPoojaProducts() {
  const target = document.getElementById("productCategories");
  if (!target) return;
  const groups = {};
  POOJA_CATALOG.forEach(p => (groups[p.category] ||= []).push(p));
  target.innerHTML = Object.entries(groups).map(([category, items]) => `
    <section class="pooja-category">
      <div class="category-title"><h3>${category}</h3><span>Ganesh Pooja Essential</span></div>
      <div class="product-gallery">
        ${items.map(p => `
          <article class="product-card">
            <img src="images/${p.image}" alt="${p.name} pooja article">
            <div class="product-info">
              <p class="eyebrow">${p.category}</p>
              <h2>${p.name}</h2>
              <p>${p.description}</p>
              <p class="price-line"><strong>Price:</strong> ${p.price}</p>
              <p class="size-line"><strong>Available sizes:</strong> 100 gm / 200 gm</p>
              <button type="button" class="btn choose-pooja" data-product="${p.name}">Choose for Booking</button>
            </div>
          </article>`).join("")}
      </div>
    </section>`).join("");

  target.querySelectorAll(".choose-pooja").forEach(btn => btn.addEventListener("click", () => {
    const select = document.querySelector(".poojaProduct");
    if (select) {
      select.value = btn.dataset.product;
      document.getElementById("poojaBooking")?.scrollIntoView({behavior:"smooth"});
    }
  }));
}

function setupPoojaBooking() {
  const form = document.getElementById("poojaBookingForm");
  if (!form) return;
  const fillProduct = select => {
    select.innerHTML = POOJA_CATALOG.map(p => `<option value="${p.name}">${p.name} — ${p.category}</option>`).join("");
  };
  const first = form.querySelector(".poojaProduct");
  if (first) fillProduct(first);

  const addBtn = document.getElementById("addPoojaItem");
  const rows = document.getElementById("itemRows");
  addBtn?.addEventListener("click", () => {
    const row = document.createElement("div");
    row.className = "pooja-item-row";
    row.innerHTML = `<label>Product Name *<select class="poojaProduct" required></select></label>
      <label>Qty *<input class="poojaQty" type="number" min="1" value="1" required></label>
      <label>Size *<select class="poojaSize" required><option value="100 gm">100 gm</option><option value="200 gm">200 gm</option></select></label>
      <button type="button" class="remove-item" aria-label="Remove item">×</button>`;
    rows.appendChild(row);
    fillProduct(row.querySelector(".poojaProduct"));
  });
  rows?.addEventListener("click", e => {
    if (e.target.classList.contains("remove-item")) {
      const all = rows.querySelectorAll(".pooja-item-row");
      if (all.length > 1) e.target.closest(".pooja-item-row").remove();
    }
  });
  form.onsubmit = e => {
    e.preventDefault();
    if (!form.checkValidity()) { form.reportValidity(); return; }
    const v = id => (document.getElementById(id)?.value || "").trim();
    const items = [...form.querySelectorAll(".pooja-item-row")].map((row, i) => {
      const product = row.querySelector(".poojaProduct").value;
      const qty = row.querySelector(".poojaQty").value;
      const size = row.querySelector(".poojaSize").value;
      return `${i+1}. ${product} — ${qty} × ${size}`;
    }).join("\n");
    const delivery = v("poojaDelivery");
    const address = v("poojaAddress") || (delivery.startsWith("Shop") ? "Not required — Shop Pickup" : "Not provided");
    const msg = `🙏 NEW POOJA ARTICLE BOOKING
Customer Name: ${v("poojaName")}
Contact No: ${v("poojaMobile")}

Selected Products:
${items}

Delivery Mode: ${delivery}
Address: ${address}
Note: ${v("poojaNote") || "None"}

Status: Pending manual confirmation
S.B. Joshi Enterprises, 1237 Matruchaya Apartment, Krantivir Vasudev Balvant Phadke Road, Opp. Khunya Murlidhar Mandir, Sadashiv Peth, Pune 411030`;
    document.getElementById("poojaMsg").textContent = "Opening WhatsApp…";
    window.open("https://wa.me/918857874068?text=" + encodeURIComponent(msg), "_blank");
  };
}

document.addEventListener("DOMContentLoaded", () => { renderPoojaProducts(); setupPoojaBooking(); });
